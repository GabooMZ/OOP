# Ejercicios - Básicos

Ubíquese en la **carpeta fuente del proyecto** deseado, use:

```
cd <assignments/Proyecto>

Ej.- cd assignments/00-HelloWorld

```
Regresar a una **carpeta anterior**, use:

```
Ej.- cd ../

```

Regrese a la **carpeta fuente inical, como está cuando cargas el codespace**, use:

```
Ej.- cd ../../

```


